import express from "express";
import swaggerUi from "swagger-ui-express";
import { swaggerSpec } from "./swagger.mjs";

import { sequelize, initDb, Book, Category } from "../src/db/sequelize.mjs";
import { success } from "./routes/helper.mjs";
import cors from "cors";
const __dirname = import.meta.dirname;

const app = express();
const port = 3000;

//le middleware express.json() pour analyser le corps des requêtes JSON.
app.use(express.json());

app.use(
  cors({
    origin: "http://localhost:5173", // ou l’URL de ton frontend
  })
);

app.set("view engine", "ejs");
app.set("views", __dirname + "/views"); //indique le dossier ou sont les vues

app.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpec, { explorer: true })
);

app.get("/", (req, res) => {
  Book.findAll({ order: ["datePublication"], limit: 5 })
    .then((books) => {
      const message = "Les livres ont bien été récupéré";
      res.json(success(message, books));
    })
    .catch((error) => {
      console.error("Error fetching books:", error);
      const message =
        "Les livres n'ont pas pu être récupérés. Merci de réessayer dans quelques instants.";
      res.status(500).json({ message, data: error });
    });
});
app.use(express.static(__dirname + "/public"));
//redirect /api vers localhost/
app.get("/api/", (req, res) => {
  res.redirect(`http://localhost:${port}/`);
});

import { loginRouter } from "./routes/login.mjs";
app.use("/api/login", loginRouter);

import { registerRouter } from "./routes/register.mjs";
app.use("/api/register", registerRouter);

import { categorieRouter } from "./routes/categorie.mjs";
app.use("/api/categories", categorieRouter);

import { booksRouter } from "./routes/books.mjs";
app.use("/api/books", booksRouter);

import { userRouter } from "./routes/users.mjs";
app.use("/api/users", userRouter);

import { authorRouter } from "./routes/authors.mjs";
app.use("/api/authors", authorRouter);

const UPLOADS_DIR = __dirname + "/uploads";
app.use("/uploads", express.static(UPLOADS_DIR));

// Si aucune route ne correspondant à l'URL demandée par le consommateur
// On place le code a la fin, car la requette passera d'abord par les autres route, et si aucune ne correspond la route n'est pas trouvé donc 404
app.use(({ res }) => {
  const message =
    "Impossible de trouver la ressource demandée ! Vous pouvez essayer une autre URL.";
  res.status(404).json(message);
});

app.listen(3000, "0.0.0.0");

sequelize
  .authenticate()
  .then((_) => console.log("Connexion à la base de données réussie."))
  .catch((error) => console.error("Erreur de connexion à la base de données"));

initDb();
