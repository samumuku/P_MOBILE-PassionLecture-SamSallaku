import jwt from "jsonwebtoken";
import { privKey } from "./privKey.mjs";

const auth = (req, res, next) => {
  const headerAuth = req.headers.authorization;

  if (!headerAuth) {
    const message =
      "Aucun jeton d'authentification trouvé, veuillez en mettre un";
    return res.status(401).json({ message });
  } else {
    const jwtToken = headerAuth.split(" ")[1];

    const validToken = jwt.verify(jwtToken, privKey, (error, decoded) => {
      if (error) {
        const message = "Accès refusé, jeton expiré ou invalide";
        return res.status(401).json({ message });
      }
      const userId = decoded.userId;

      if (req.body.userId && req.body.userId !== userId) {
        const message = "Utilisateur inexistant";
        return res.status(401).json({ message });
      } else {
        next();
      }
    });
  }
};

export default auth;
