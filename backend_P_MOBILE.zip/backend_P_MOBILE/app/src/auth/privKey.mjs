const privKey = "SSS-LECTURE-PRIVATE-KEY";

export { privKey };
