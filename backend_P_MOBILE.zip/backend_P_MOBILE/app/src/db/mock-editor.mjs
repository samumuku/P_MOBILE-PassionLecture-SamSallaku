let editors = [
  { nom: "Gallimard" },
  { nom: "Hachette Livre" },
  { nom: "Flammarion" },
  { nom: "Seuil" },
  { nom: "Albin Michel" },
  { nom: "Actes Sud" },
  { nom: "Grasset" },
  { nom: "Fayard" },
  { nom: "Dunod" },
  { nom: "Larousse" },
  { nom: "Nathan" },
  { nom: "Pocket" },
  { nom: "Le Livre de Poche" },
  { nom: "Puf" },
  { nom: "Casterman" },
  { nom: "Bayard" },
  { nom: "Éditions de Minuit" },
  { nom: "Robert Laffont" },
  { nom: "J'ai Lu" },
  { nom: "Éditions Belfond" },
];

export { editors };
