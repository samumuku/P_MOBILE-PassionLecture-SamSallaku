let categorys = [
  { nom: "Roman" },
  { nom: "Science-fiction" },
  { nom: "Fantasy" },
  { nom: "Biographie" },
  { nom: "Histoire" },
  { nom: "Thriller" },
  { nom: "Policier" },
  { nom: "Philosophie" },
  { nom: "Essai" },
  { nom: "Poésie" },
];

export { categorys };
