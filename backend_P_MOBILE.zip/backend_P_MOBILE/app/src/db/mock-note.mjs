let notes = [
  {
    livre_fk: 1,
    user_fk: 1,
    note: 5,
  },
  {
    livre_fk: 2,
    user_fk: 1,
    note: 4,
  },
  {
    livre_fk: 3,
    user_fk: 1,
    note: 3,
  },
  {
    livre_fk: 4,
    user_fk: 1,
    note: 4,
  },
  {
    livre_fk: 5,
    user_fk: 2,
    note: 5,
  },
  {
    livre_fk: 6,
    user_fk: 2,
    note: 3,
  },
  {
    livre_fk: 7,
    user_fk: 2,
    note: 4,
  },
  {
    livre_fk: 8,
    user_fk: 2,
    note: 2,
  },
  {
    livre_fk: 9,
    user_fk: 3,
    note: 5,
  },
  {
    livre_fk: 10,
    user_fk: 3,
    note: 4,
  },
  {
    livre_fk: 11,
    user_fk: 3,
    note: 3,
  },
  {
    livre_fk: 12,
    user_fk: 3,
    note: 2,
  },
  {
    livre_fk: 13,
    user_fk: 1,
    note: 5,
  },
  {
    livre_fk: 14,
    user_fk: 2,
    note: 4,
  },
  {
    livre_fk: 15,
    user_fk: 2,
    note: 5,
  },
  {
    livre_fk: 16,
    user_fk: 1,
    note: 3,
  },
  {
    livre_fk: 17,
    user_fk: 3,
    note: 4,
  },
  {
    livre_fk: 18,
    user_fk: 2,
    note: 2,
  },
  {
    livre_fk: 19,
    user_fk: 1,
    note: 3,
  },
  {
    livre_fk: 20,
    user_fk: 3,
    note: 5,
  },
];

export { notes };
