let users = [
  {
    pseudo: "Admin01",
    password: "password1",
    dateEntree: "2023-01-15",
    isAdmin: true,
  },
  {
    pseudo: "UserAlpha",
    password: "password2",
    dateEntree: "2023-05-22",
    isAdmin: false,
  },
  {
    pseudo: "BetaUser",
    password: "password3",
    dateEntree: "2024-02-10",
    isAdmin: false,
  },
];
export { users };
