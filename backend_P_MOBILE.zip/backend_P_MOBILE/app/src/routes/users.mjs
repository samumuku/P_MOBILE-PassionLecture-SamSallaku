import express from "express";
import auth from "../auth/auth.mjs";
import { success } from "../routes/helper.mjs";
import { Book, User } from "../db/sequelize.mjs";

const userRouter = express();

userRouter.get("/:id/books", auth, (req, res) => {
  Book.findAll({ where: { user_fk: req.params.id } })
    .then((books) => {
      const message = `Les livres publiés ont bien été récupérés. ${books.length}`;
      return res.json(success(message, books));
    })
    .catch((error) => {
      const message = `Les livres n'ont pas pu être récupérés. Veuillez reéssayer dans quelques instants.`;
      res.status(500).json({ message, data: error });
    });
});

export { userRouter };
