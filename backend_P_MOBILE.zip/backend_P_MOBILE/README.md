# backend_P_MOBILE

1. créer les dockers
2. créer la db avec le script createDb.sql
3. démarrer le backend
4. `docker cp insert_epubs.sql db_p_mobile:/insert_epubs.sql`
5. `docker exec -i db_p_mobile mysql -u root -proot db_passionlecture < insert_epubs.sql`

## infos

le script create_script.sh crée un fichier sql avec des UPDATE t_livre SET livre = (livre)...
le livre est en hexadécimal
