
# Dossier contenant les fichiers .epub
EPUB_FOLDER="./books"
# Nom du fichier de sortie SQL
OUTPUT_SQL="insert_epubs.sql"

# vide le fichie precedenet
> "$OUTPUT_SQL"

# Compteur d'ID (commence à 1, à adapter si nécessaire)
id=1

for file in "$EPUB_FOLDER"/*.epub; do
    [ -e "$file" ] || continue

    hexdata=$(xxd -p "$file" | tr -d '\n')

    echo "UPDATE t_livre SET livre = 0x$hexdata WHERE livre_id = $id;" >> "$OUTPUT_SQL"

    id=$((id + 1))
done

echo "Script SQL généré : $OUTPUT_SQL"